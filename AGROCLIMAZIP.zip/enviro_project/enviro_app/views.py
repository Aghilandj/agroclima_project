from django.shortcuts import render
from django.http import JsonResponse
import requests
api_key= "2c077bee4fd4b4fdfe598501bfe8bbca"

def get_weather(api_key, latitude, longitude):
    weather_url = f"https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={api_key}"
    response = requests.get(weather_url)
    if response.status_code == 200:
        data = response.json()
        weather = {
            "description": data["weather"][0]["description"],
            "temperature": data["main"]["temp"],
            "humidity": data["main"]["humidity"],
            "pressure": data["main"]["pressure"],
            "wind_speed": data["wind"]["speed"]
        }
        return weather
    else:
        return None

def get_aqi(api_key, latitude, longitude):
    aqi_url = f"http://api.openweathermap.org/data/2.5/air_pollution?lat={latitude}&lon={longitude}&appid={api_key}"
    response = requests.get(aqi_url)
    if response.status_code == 200:
        data = response.json()
        aqi = data["list"][0]["main"]["aqi"]
        pollutants = data["list"][0]["components"]
        return aqi, pollutants
    else:
        return None, None

def analyze_location(weather, aqi, wqi):
    recommendation = "Unknown"
    if weather and aqi:  # Check if weather and aqi are not None
        if weather["temperature"] > 20 and weather["humidity"] < 60 and aqi < 50 and wqi > 7:
            recommendation = "Excellent for Agriculture and Rural Development"
        elif weather["temperature"] > 15 and weather["humidity"] < 70 and aqi < 70 and wqi > 5:
            recommendation = "Good for Agriculture and Rural Development"
        elif weather["temperature"] > 10 and weather["humidity"] < 80 and aqi < 100 and wqi > 3:
            recommendation = "Fair for Agriculture and Rural Development"
        else:
            recommendation = "Fair for Agriculture and Rural Development"
    else:
        recommendation = "Data not available for analysis"
    return recommendation

def index(request):
    return render(request, 'enviro_app/index.html')

def get_data(request):
    latitude = request.GET.get('latitude')
    longitude = request.GET.get('longitude')
    if not latitude or not longitude:
        return JsonResponse({'error': 'Invalid or missing latitude/longitude'}, status=400)
    weather = get_weather(api_key, latitude, longitude)
    aqi, pollutants = get_aqi(api_key, latitude, longitude)
    water_quality_index = 7.5  # Example constant value
    recommendation = analyze_location(weather, aqi, water_quality_index)
    return JsonResponse({
        'weather': weather,
        'aqi': aqi,
        'pollutants': pollutants,
        'water_quality_index': water_quality_index,
        'recommendation': recommendation
    })
